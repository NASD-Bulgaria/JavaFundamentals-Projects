package excercises;

public class Labels {
	
	public final static String labelAdd = "Add";
	public final static String labelEdit = "Edit";
	public final static String labelSave = "Save";
	public final static String labelOk = "OK";
	public final static String labelCancel = "Cancel";
}
