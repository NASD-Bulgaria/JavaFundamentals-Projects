package excercises;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class AddEditDataForm extends JFrame{
	
	private JLabel labelFirstName;
	private JLabel labelLastName;
	private JLabel labelYears;
	private JLabel labelAddress;
	private JLabel labelPhone;
	
	private JTextField textFieldFirstName;
	private JTextField textFieldLastName;
	private JTextField textFieldYears;
	private JTextField textFieldAddress;
	private JTextField textFieldPhone;
	
	private JButton buttonOk;
	private JButton buttonCancel;
	
	private MainForm mainForm;
	
	AddEditDataForm(String text, MainForm mainForm){
		super(text + " person information");
		setLayout(null);
		this.mainForm = mainForm;
		
		labelFirstName = new JLabel("First Name: ");
		labelLastName= new JLabel("Last Name: ");
		labelYears= new JLabel("Years: ");
		labelAddress= new JLabel("Address: ");
		labelPhone= new JLabel("Phone: ");
		
		textFieldFirstName = new JTextField();
		textFieldLastName = new JTextField();
		textFieldYears = new JTextField();
		textFieldAddress = new JTextField();
		textFieldPhone = new JTextField();
		
		buttonOk = new JButton(Labels.labelOk);
		buttonCancel = new JButton(Labels.labelCancel);
		
		add(labelFirstName).setBounds(10, 10, 80, 20);
		add(labelLastName).setBounds(10, 40, 80, 20);
		add(labelYears).setBounds(10, 70, 80, 20);
		add(labelAddress).setBounds(10, 100, 80, 20);
		add(labelPhone).setBounds(10, 130, 80, 20);
		
		add(textFieldFirstName).setBounds(90, 10, 150, 20);
		add(textFieldLastName).setBounds(90, 40, 150, 20);
		add(textFieldYears).setBounds(90, 70, 150, 20);
		add(textFieldAddress).setBounds(90, 100, 150, 20);
		add(textFieldPhone).setBounds(90, 130, 150, 20);
		
		add(buttonOk).setBounds(30, 180, 60, 30);
		add(buttonCancel).setBounds(120, 180, 80, 30);
		
		ButtonHandler handler = new ButtonHandler();
		buttonOk.addActionListener(handler);
		buttonCancel.addActionListener(handler);
	}
	
	private class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == buttonOk){
				String firstName = textFieldFirstName.getText();
				String lastName = textFieldLastName.getText();
				int years = Integer.parseInt(textFieldYears.getText());
				String address = textFieldAddress.getText();
				int phone = Integer.parseInt(textFieldPhone.getText());
				
				PersonInformation personInformation = new PersonInformation(firstName, lastName, years, address, phone);
				mainForm.addPersonInformation(personInformation);
				System.out.println("person information from add form");
				dispose();
			} else if(event.getSource() == buttonCancel){
				dispose();
			}
		}
		
	}
	
}
