package excercises;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;


public class LoadFromFileForm extends JFrame{
	private JButton buttonOK;
	private JButton buttonCancel;
	
	public LoadFromFileForm() {
		super("Test using JFilePicker");
        
        setLayout(new FlowLayout());
 
        // set up a file picker component
        JFilePicker filePicker = new JFilePicker("Pick a file", "Browse...");
        filePicker.setMode(JFilePicker.MODE_SAVE);
        filePicker.addFileTypeFilter(".jpg", "JPEG Images");
        filePicker.addFileTypeFilter(".mp4", "MPEG-4 Videos");
         
        // access JFileChooser class directly
        JFileChooser fileChooser = filePicker.getFileChooser();
        fileChooser.setCurrentDirectory(new File("D:/"));
         
        // add the component to the frame
        add(filePicker);
         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 100);
        setLocationRelativeTo(null);    // center on screen
	
        ButtonHandler handler = new ButtonHandler();
        buttonOK = new JButton(Labels.labelOk);
        buttonCancel = new JButton(Labels.labelCancel);
        add(buttonOK);
        add(buttonCancel);
        
        buttonOK.addActionListener(handler);
        buttonCancel.addActionListener(handler);
	
	
	}
	
	private class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == buttonOK){
				
			} else if(event.getSource() == buttonCancel){
				MainForm form = new MainForm();				
				form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				form.setSize(400, 400);
				form.setVisible(true);
				dispose();
			}
		}
		
	}
	
}
