package excercises;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MainForm extends JFrame{
	
	private JButton buttonAdd;
	private JButton buttonEdit;
	private JButton buttonSave;
	private JScrollPane scrollPane;
	private JTable tableData;
	
	private String[] columnNames = {"First Name", "Last Name", "Years", "Address", "Phone"};
	private Object[][] data = {
			{"Kathy", "Smith", new Integer(15), "NYC", "084342"},
	};
	
	MainForm(){
		super("Personal Information");
		setLayout(null);

	buttonAdd = new JButton(Labels.labelAdd);
	buttonEdit = new JButton(Labels.labelEdit);
	buttonSave = new JButton(Labels.labelSave);
	
	tableData = new JTable(new DefaultTableModel(data, columnNames));
	
	add(buttonAdd).setBounds(10, 10, 60, 30);
	add(buttonEdit).setBounds(80, 10, 60, 30);
	add(buttonSave).setBounds(150, 10, 70, 30);
	
	scrollPane = new JScrollPane(tableData);
	tableData.setFillsViewportHeight(true);

	tableData.setEnabled(false);
	add(scrollPane).setBounds(10, 70, 350, 270);
	
	ButtonHandler handler = new ButtonHandler();
	buttonAdd.addActionListener(handler);
	buttonEdit.addActionListener(handler);
	buttonSave.addActionListener(handler);
	
	}
	
	private class ButtonHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource() == buttonAdd){
				AddEditDataForm form = new AddEditDataForm(Labels.labelAdd, MainForm.this);
				form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				form.setSize(280, 280);
				form.setVisible(true);
				
				
				
			} else if(event.getSource() == buttonEdit){
				AddEditDataForm form = new AddEditDataForm(Labels.labelEdit, MainForm.this);				
				form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				form.setSize(280, 280);
				form.setVisible(true);
			
			} else if(event.getSource() == buttonSave){
				
			}
		}
		
	}
	
	public void addPersonInformation(PersonInformation personInformation){
		Object[][] data = new Object [this.data.length+1][this.data[0].length];
		for(int row = 0; row < this.data.length; row++){
			for(int col = 0; col < this.data[0].length; col++){
				data[row][col] = this.data[row][col];
			}
		}
		
		data[this.data.length][0] = personInformation.getFirstName();
		data[this.data.length][1] = personInformation.getLastName();
		data[this.data.length][2] = personInformation.getYears();
		data[this.data.length][3] = personInformation.getAddress();
		data[this.data.length][4] = personInformation.getPhone();
		
		DefaultTableModel model = (DefaultTableModel) tableData.getModel();
		model.addRow(data[1]);
		//MainForm.this.repaint();
		
	}
}
