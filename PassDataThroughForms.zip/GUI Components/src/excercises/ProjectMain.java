package excercises;

import javax.swing.JFrame;


public class ProjectMain {

	public static void main(String[] args) {


		LoadFromFileForm form = new LoadFromFileForm();
		
		form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		form.setSize(520, 200);
		form.setVisible(true);
		
		/*AddEditDataForm form = new AddEditDataForm("Add");
		
		form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		form.setSize(280, 280);
		form.setVisible(true);*/
		
		
	}

}
