package genericClassesAndMethods;

import java.util.ArrayList;

//Stack generic class declaration.
public class Stack<T> {

  private ArrayList<T> elements;

  public Stack() {
    this(10);
  }

  public Stack(int capacity) {
    int initCapacity = capacity > 0 ? capacity : 10;
    elements = new ArrayList<T>(initCapacity);
  }

  // push element onto stack
  public void push(T pushValue) {
    elements.add(pushValue);

  }

  // return the top element if not empty; else throw EmptyStackException
  public T pop() {
    if (elements.isEmpty())// if stack is empty
      throw new EmptyStackException("Stack is empty, cannot pop");
      return elements.remove(elements.size() - 1);
  }

}
